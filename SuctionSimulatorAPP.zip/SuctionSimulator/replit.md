# Suction Simulator — Project Documentation

## Overview
This is an educational web application for teaching neonatal suction patterns (Nutritive and Non-Nutritive Sucking) in speech-language pathology programs.

## Project Structure
```
/
├── index.html              # Main application (single-page, optimized for 60 FPS)
├── assets/
│   └── logo_Ibero.png      # University logo (SVG fallback in HTML)
├── docs/
│   ├── README.md           # Complete user guide and scientific documentation
│   └── perf-notes.md       # Performance optimization technical notes
├── CITATION.cff            # Academic citation metadata
├── LICENSE                 # MIT License with educational disclaimer
├── README.md               # Quick start guide
├── replit.yaml             # Replit hosting configuration
└── .gitignore              # Git exclusions

```

## Key Features
- **60 FPS Canvas Animation:** Dual synchronized panels (vacuum + respiration)
- **Real-time Metrics:** NOMAS assessment with age-adjusted bands
- **Educational Presets:** SN típico, SNN típico, Desorganizado
- **Scientific References:** Built-in evidence drawer with PubMed/PMC citations
- **Zero Dependencies:** Pure HTML5 + Canvas 2D + Vanilla JavaScript

## Performance Optimizations Applied
1. **Offscreen Canvas Buffers:** Static grids cached, ~40% frame time reduction
2. **Pre-calculated Pixel Mappings:** xPixTop/xPixBot as Float32Arrays
3. **Reusable Analysis Buffer:** Eliminates GC pressure (was 10 allocations/sec)
4. **10Hz Metrics Throttling:** Analysis decoupled from 60Hz render loop
5. **Debounced Resize:** Prevents rapid grid rebuilds

**Result:** Stable 58-60 FPS on 2019 mid-range hardware

## Running the Simulator
The workflow is already configured. Just click **Run** or visit the webview.

## Deployment Options
- **Replit:** Already configured (you're here!)
- **GitHub Pages:** Push to GitHub, enable Pages in Settings
- **Vercel:** `vercel --prod`
- **Local:** `python3 -m http.server 5000`

## Documentation
- **User Guide:** [docs/README.md](docs/README.md) — Complete controls, parameters, NOMAS criteria
- **Performance:** [docs/perf-notes.md](docs/perf-notes.md) — Technical optimization details
- **Citation:** [CITATION.cff](CITATION.cff) — Academic metadata

## Educational Disclaimer
⚠️ **For teaching purposes only.** This simulator is NOT a medical device and should not be used for clinical diagnosis or patient assessment.

## License
MIT License — Free for educational and research use. See [LICENSE](LICENSE) for details.

---

**Version:** 1.0.0  
**Author:** Flgo. Carlos Calvache, Ph.D. (Corporación Universitaria Iberoamericana)  
**Last Updated:** October 31, 2025
