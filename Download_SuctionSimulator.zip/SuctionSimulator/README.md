# Suction Simulator

**Simulador Didáctico de Succión Neonatal** — Educational Tool for Neonatal Feeding Patterns

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)](https://github.com/username/suction-simulator)

---

## Quick Start

### Run Locally
```bash
python3 -m http.server 5000
# Open http://localhost:5000
```

### Try Online
🔗 **Live Demo:** [https://username.github.io/suction-simulator/](https://username.github.io/suction-simulator/)

---

## What is This?

An interactive educational simulator for teaching **neonatal suction patterns** in speech-language pathology and health sciences programs. Visualizes:

- ✅ **Nutritive Sucking (SN):** Breastfeeding/bottle patterns
- ✅ **Non-Nutritive Sucking (SNN):** Pacifier patterns  
- ✅ **Suck-Swallow-Breathe (SSB) Coordination**
- ✅ **NOMAS Assessment Criteria** (educational)

---

## Features

### Real-Time Visualization
- **Top Panel:** Intraoral vacuum pressure (kPa/mmHg/Pa)
- **Bottom Panel:** Respiration + swallow markers + apnea bands
- **60 FPS Animation:** Smooth waveform rendering

### Configurable Parameters
- Vacuum amplitude (Pmax): 0–4 kPa
- Frequency: 20–180 sucks/min
- Burst duration: 1–20 seconds
- Inter-burst pause: 0–15 seconds
- SSB ratios: 1:1:1, 2:1:1, 3:1:1 (SN) or probabilistic (SNN)

### Educational Metrics
- Real-time KPIs (frequency, IC index, median burst length)
- Age-adjusted reference bands (32-34w, 34-36w, ≥37w)
- Automated NOMAS flagging (for teaching purposes)

---

## Documentation

📖 **Full User Guide:** [docs/README.md](docs/README.md)  
⚡ **Performance Notes:** [docs/perf-notes.md](docs/perf-notes.md)  
📚 **Scientific References:** Built into the app (📎 Evidencia button)

---

## Citation

If you use this simulator in your research or teaching, please cite:

```bibtex
@software{calvache2025suction,
  author = {Calvache, Carlos},
  title = {Suction Simulator SN/SNN},
  year = {2025},
  version = {1.0},
  publisher = {Corporación Universitaria Iberoamericana},
  url = {https://github.com/username/suction-simulator}
}
```

See [CITATION.cff](CITATION.cff) for complete metadata.

---

## Technical Stack

- **Frontend:** Pure HTML5 + Canvas 2D + Vanilla JavaScript (ES6+)
- **No Dependencies:** Zero external libraries
- **Performance:** 58-60 FPS (optimized offscreen canvas caching)
- **Hosting:** Static files (works on GitHub Pages, Vercel, Replit)

---

## Development

### Project Structure
```
/
├── index.html          # Single-page app (HTML+CSS+JS inline)
├── assets/             # Logo and static resources
├── docs/               # Documentation (README, performance notes)
├── CITATION.cff        # Academic citation metadata
├── LICENSE             # MIT License
└── replit.yaml         # Replit hosting config
```

### Performance Optimizations
- Offscreen buffer caching for static grids
- Pre-calculated pixel mappings (Float32Array)
- 10Hz analysis throttling
- Reusable analysis buffer (GC-friendly)
- Debounced resize handler

See [docs/perf-notes.md](docs/perf-notes.md) for benchmarks.

---

## Deployment

### GitHub Pages
```bash
git push origin main
# Enable Pages in repo Settings → Pages → Source: main
```

### Vercel
```bash
vercel --prod
```

### Replit
Just hit **Run** — already configured via `replit.yaml`

---

## Disclaimer ⚠️

**Educational Use Only.** This simulator is NOT a medical device. Do not use for:
- Clinical diagnosis
- Patient assessment
- Treatment decisions

Real clinical evaluation requires calibrated instrumentation and professional judgment.

---

## License

[MIT License](LICENSE) — Free for educational and research use.

---

## Credits

**Principal Investigator:**  
Flgo. Carlos Calvache, Ph.D.  
Corporación Universitaria Iberoamericana — Programa de Fonoaudiología

**Contributing:**  
Issues and PRs welcome! See [docs/README.md](docs/README.md) for contribution guidelines.

---

**Version:** 1.0.0 | **Last Updated:** October 31, 2025
